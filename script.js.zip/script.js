"use strict";


/* ==========================================
   REGRESSION SOCIETY
   Catalogue APIs:
   AniList: anime and manga
   Gutendex: public-domain books
   localStorage: personal library
========================================== */

const ANILIST_API = "https://graphql.anilist.co";
const BOOK_API = "https://gutendex.com/books/";

const STORAGE_LIBRARY = "regressionSocietyLibraryV1";
const STORAGE_PROGRESS = "regressionSocietyProgressV1";

let animePage = 1;
let mangaPage = 1;
let booksPage = 1;

let animeSort = "TRENDING_DESC";
let mangaSort = "TRENDING_DESC";

let currentReaderBook = null;
let readerFontSize = 18;
let toastTimer = null;

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

/* ==========================================
   UTILITIES
========================================== */

function safeRead(key, fallback) {
    try {
        const value = localStorage.getItem(key);
        return value ? JSON.parse(value) : fallback;
    } catch {
        return fallback;
    }
}

function getLibrary() {
    const data = safeRead(STORAGE_LIBRARY, []);
    return Array.isArray(data) ? data : [];
}

function getProgress() {
    return safeRead(STORAGE_PROGRESS, {});
}

function saveLibrary(data) {
    try {
        localStorage.setItem(STORAGE_LIBRARY, JSON.stringify(data));
        return true;
    } catch {
        showToast("Unable to save. Browser storage may be full.");
        return false;
    }
}

function showToast(message) {
    const toast = $("#toast");
    if (!toast) {
        alert(message);
        return;
    }

    toast.textContent = message;
    toast.classList.add("visible");

    clearTimeout(toastTimer);

    toastTimer = setTimeout(() => {
        toast.classList.remove("visible");
    }, 2600);
}

function setStatus(selector, message) {
    const element = $(selector);
    if (element) element.textContent = message;
}

function safeText(value) {
    return String(value ?? "");
}

function plainText(value) {
    const element = document.createElement("div");
    element.innerHTML = safeText(value);

    return (element.textContent || "")
        .replace(/\s+/g, " ")
        .trim();
}

function titleFor(item) {
    if (item.kind === "book") {
        return item.title || "Untitled book";
    }

    return item.title?.english ||
        item.title?.romaji ||
        item.title?.native ||
        "Untitled";
}

function coverFor(item) {
    if (item.kind === "book") {
        return item.cover || "";
    }

    return item.coverImage?.large ||
        item.coverImage?.medium ||
        "";
}

function yearFor(item) {
    if (item.kind === "book") {
        return item.year || "Classic literature";
    }

    return item.startDate?.year || "Year unavailable";
}

function scoreFor(item) {
    if (item.kind === "book") {
        return "Public-domain book";
    }

    return item.averageScore
        ? `★ ${(item.averageScore / 10).toFixed(1)}`
        : "Not rated";
}

function isSaved(item) {
    return getLibrary().some(saved =>
        saved.kind === item.kind &&
        String(saved.id) === String(item.id)
    );
}

function emptyState(message) {
    const element = document.createElement("div");
    element.className = "empty-state";
    element.textContent = message;
    return element;
}

function setButtonLoading(button, loading) {
    if (button) button.disabled = loading;
}

/* ==========================================
   NAVIGATION
========================================== */

function showPage(pageName) {
    const target = document.getElementById(`page-${pageName}`);

    if (!target) {
        console.warn(`Page not found: page-${pageName}`);
        return;
    }

    $$(".page").forEach(page => {
        page.classList.toggle("active-page", page === target);
    });

    $$(".nav-link").forEach(button => {
        button.classList.toggle(
            "active",
            button.dataset.page === pageName
        );
    });

    $("#navigation")?.classList.remove("open");

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

    if (pageName === "library") renderLibrary();

    if (pageName === "anime" && !$("#anime-results")?.children.length) {
        loadAnime();
    }

    if (pageName === "manga" && !$("#manga-results")?.children.length) {
        loadManga();
    }

    if (pageName === "novels" && !$("#books-results")?.children.length) {
        loadBooks();
    }
}

document.addEventListener("click", event => {
    const pageButton = event.target.closest("[data-page]");

    if (pageButton) {
        event.preventDefault();
        showPage(pageButton.dataset.page);
    }

    if (event.target.closest("[data-close-modal]")) {
        closeModal();
    }
});

$("#menu-toggle")?.addEventListener("click", () => {
    $("#navigation")?.classList.toggle("open");
});

$("#profile-button")?.addEventListener("click", () => {
    showPage("library");
});

if ($("#current-year")) {
    $("#current-year").textContent = new Date().getFullYear();
}

/* ==========================================
   ANILIST API
========================================== */

async function anilistRequest(query, variables = {}) {
    const response = await fetch(ANILIST_API, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Accept": "application/json"
        },
        body: JSON.stringify({ query, variables })
    });

    if (!response.ok) {
        throw new Error(`Catalogue request failed (${response.status}).`);
    }

    const payload = await response.json();

    if (payload.errors?.length) {
        throw new Error(payload.errors[0].message || "Catalogue error.");
    }

    if (!payload.data) {
        throw new Error("No catalogue data was returned.");
    }

    return payload.data;
}

const MEDIA_QUERY = `
query (
    $page: Int,
    $perPage: Int,
    $type: MediaType!,
    $sort: [MediaSort],
    $search: String
) {
    Page(page: $page, perPage: $perPage) {
        pageInfo {
            currentPage
            hasNextPage
        }
        media(
            type: $type,
            sort: $sort,
            search: $search,
            isAdult: false
        ) {
            id
            title {
                romaji
                english
                native
            }
            coverImage {
                large
                medium
            }
            description(asHtml: false)
            genres
            averageScore
            episodes
            chapters
            volumes
            status
            siteUrl
            startDate {
                year
            }
            format
        }
    }
}`;

async function fetchMedia({
    type,
    page = 1,
    sort = "TRENDING_DESC",
    search = ""
}) {
    const data = await anilistRequest(MEDIA_QUERY, {
        page,
        perPage: 15,
        type,
        sort: [sort],
        search: search || null
    });

    return data.Page;
}

/* ==========================================
   MEDIA CARDS
========================================== */

function createMediaCard(item) {
    const card = document.createElement("article");
    card.className = "media-card";

    const coverButton = document.createElement("button");
    coverButton.className = "media-cover";
    coverButton.type = "button";
    coverButton.setAttribute("aria-label", `View ${titleFor(item)}`);

    const imageURL = coverFor(item);

    if (imageURL) {
        const image = document.createElement("img");
        image.src = imageURL;
        image.alt = titleFor(item);
        image.loading = "lazy";

        image.addEventListener("error", () => {
            const fallback = document.createElement("span");
            fallback.className = "cover-fallback";
            fallback.textContent = "RS";
            image.replaceWith(fallback);
        }, { once: true });

        coverButton.appendChild(image);
    } else {
        const fallback = document.createElement("span");
        fallback.className = "cover-fallback";
        fallback.textContent = "RS";
        coverButton.appendChild(fallback);
    }

    coverButton.addEventListener("click", () => openDetails(item));

    const info = document.createElement("div");
    info.className = "media-info";

    const heading = document.createElement("h3");
    heading.className = "media-title";
    heading.textContent = titleFor(item);

    const meta = document.createElement("p");
    meta.className = "media-meta";
    meta.textContent = `${yearFor(item)} · ${scoreFor(item)}`;

    const actions = document.createElement("div");
    actions.className = "media-actions";

    const detailsButton = document.createElement("button");
    detailsButton.type = "button";
    detailsButton.className = "small-button";
    detailsButton.textContent = item.kind === "book" ? "Read" : "Details";

    detailsButton.addEventListener("click", () => openDetails(item));

    const saveButton = document.createElement("button");
    saveButton.type = "button";
    saveButton.className = "small-button";
    saveButton.textContent = isSaved(item) ? "♥ Saved" : "+ Save";

    saveButton.addEventListener("click", () => {
        toggleSaved(item);
        saveButton.textContent = isSaved(item) ? "♥ Saved" : "+ Save";
    });

    actions.append(detailsButton, saveButton);
    info.append(heading, meta, actions);
    card.append(coverButton, info);

    return card;
}

function renderCards(selector, items, message) {
    const container = $(selector);
    if (!container) return;

    container.replaceChildren();

    if (!items || !items.length) {
        container.appendChild(emptyState(message));
        return;
    }

    const fragment = document.createDocumentFragment();

    items.forEach(item => {
        fragment.appendChild(createMediaCard(item));
    });

    container.appendChild(fragment);
}

/* ==========================================
   ANIME SEARCH AND CATALOGUE
========================================== */

async function loadAnime(options = {}) {
    const { append = false, search = "", sort = animeSort } = options;
    const page = append ? animePage + 1 : 1;

    const container = $("#anime-results");
    if (!container) return;

    setStatus("#anime-status", "Searching anime archives...");

    if (!append) {
        container.replaceChildren();
        setButtonLoading($("#anime-load-more"), true);
    }

    try {
        const result = await fetchMedia({
            type: "ANIME",
            page,
            sort,
            search
        });

        const items = result.media.map(item => ({
            ...item,
            kind: "anime"
        }));

        if (!append) container.replaceChildren();

        const fragment = document.createDocumentFragment();

        items.forEach(item => {
            fragment.appendChild(createMediaCard(item));
        });

        container.appendChild(fragment);

        animePage = page;

        setButtonLoading(
            $("#anime-load-more"),
            !result.pageInfo.hasNextPage
        );

        setStatus(
            "#anime-status",
            `${container.children.length} titles loaded.`
        );
    } catch (error) {
        console.error("Anime error:", error);
        setStatus("#anime-status", error.message || "Anime catalogue unavailable.");
        setButtonLoading($("#anime-load-more"), false);
    }
}

$("#anime-search-form")?.addEventListener("submit", event => {
    event.preventDefault();

    loadAnime({
        search: $("#anime-search-input")?.value.trim() || ""
    });
});

$("#anime-filters")?.addEventListener("click", event => {
    const button = event.target.closest("[data-anime-sort]");
    if (!button) return;

    $$("#anime-filters .filter-chip").forEach(chip => {
        chip.classList.toggle("active", chip === button);
    });

    animeSort = button.dataset.animeSort;
    loadAnime({ sort: animeSort });
});

$("#anime-load-more")?.addEventListener("click", () => {
    loadAnime({
        append: true,
        sort: animeSort,
        search: $("#anime-search-input")?.value.trim() || ""
    });
});

/* ==========================================
   MANGA / MANHWA / MANHUA
========================================== */

async function loadManga(options = {}) {
    const { append = false, search = "", sort = mangaSort } = options;
    const page = append ? mangaPage + 1 : 1;

    const container = $("#manga-results");
    if (!container) return;

    setStatus("#manga-status", "Searching manga, manhwa and manhua...");

    if (!append) {
        container.replaceChildren();
        setButtonLoading($("#manga-load-more"), true);
    }

    try {
        const result = await fetchMedia({
            type: "MANGA",
            page,
            sort,
            search
        });

        const items = result.media.map(item => ({
            ...item,
            kind: "manga"
        }));

        if (!append) container.replaceChildren();

        const fragment = document.createDocumentFragment();

        items.forEach(item => {
            fragment.appendChild(createMediaCard(item));
        });

        container.appendChild(fragment);
        mangaPage = page;

        setButtonLoading(
            $("#manga-load-more"),
            !result.pageInfo.hasNextPage
        );

        setStatus(
            "#manga-status",
            `${container.children.length} titles loaded.`
        );
    } catch (error) {
        console.error("Manga error:", error);
        setStatus("#manga-status", error.message || "Manga catalogue unavailable.");
        setButtonLoading($("#manga-load-more"), false);
    }
}

$("#manga-search-form")?.addEventListener("submit", event => {
    event.preventDefault();

    loadManga({
        search: $("#manga-search-input")?.value.trim() || ""
    });
});

$("#manga-filters")?.addEventListener("click", event => {
    const button = event.target.closest("[data-manga-sort]");
    if (!button) return;

    $$("#manga-filters .filter-chip").forEach(chip => {
        chip.classList.toggle("active", chip === button);
    });

    mangaSort = button.dataset.mangaSort;
    loadManga({ sort: mangaSort });
});

$("#manga-load-more")?.addEventListener("click", () => {
    loadManga({
        append: true,
        sort: mangaSort,
        search: $("#manga-search-input")?.value.trim() || ""
    });
});

/* ==========================================
   PUBLIC-DOMAIN BOOKS
========================================== */

async function fetchBooks({ page = 1, search = "" } = {}) {
    const url = new URL(BOOK_API);

    url.searchParams.set("page", page);

    if (search) {
        url.searchParams.set("search", search);
    }

    const response = await fetch(url);

    if (!response.ok) {
        throw new Error(`Book catalogue request failed (${response.status}).`);
    }

    return response.json();
}

function mapBook(book) {
    return {
        id: String(book.id),
        kind: "book",
        title: book.title || "Untitled book",
        author: (book.authors || [])
            .map(author => author.name)
            .join(", ") || "Unknown author",
        cover: book.formats?.["image/jpeg"] || "",
        year: book.authors?.[0]?.birth_year || "Classic",
        description: "A public-domain book listed by Project Gutenberg.",
        genres: book.bookshelves || [],
        siteUrl: `https://www.gutenberg.org/ebooks/${book.id}`,
        formats: book.formats || {},
        downloadCount: book.download_count || 0
    };
}

async function loadBooks(options = {}) {
    const { append = false, search = "" } = options;
    const page = append ? booksPage + 1 : 1;

    const container = $("#books-results");
    if (!container) return;

    setStatus("#books-status", "Searching book archives...");

    if (!append) {
        container.replaceChildren();
        setButtonLoading($("#books-load-more"), true);
    }

    try {
        const data = await fetchBooks({ page, search });
        const books = data.results.map(mapBook);

        if (!append) container.replaceChildren();

        books.forEach(book => {
            container.appendChild(createMediaCard(book));
        });

        booksPage = page;

        setButtonLoading($("#books-load-more"), Boolean(!data.next));

        setStatus(
            "#books-status",
            `${container.children.length} books found.`
        );
    } catch (error) {
        console.error("Books error:", error);
        setStatus("#books-status", error.message || "Book catalogue unavailable.");
        setButtonLoading($("#books-load-more"), false);
    }
}

$("#books-search-form")?.addEventListener("submit", event => {
    event.preventDefault();

    loadBooks({
        search: $("#books-search-input")?.value.trim() || ""
    });
});

$("#books-load-more")?.addEventListener("click", () => {
    loadBooks({
        append: true,
        search: $("#books-search-input")?.value.trim() || ""
    });
});

/* ==========================================
   GLOBAL SEARCH
========================================== */

$("#global-search-form")?.addEventListener("submit", async event => {
    event.preventDefault();

    const search = $("#global-search-input")?.value.trim() || "";
    const type = $("#global-search-type")?.value || "ANIME";

    if (!search) {
        setStatus("#global-search-status", "Enter a title to search.");
        $("#global-search-input")?.focus();
        return;
    }

    setStatus("#global-search-status", "Searching the Society...");
    $("#global-search-results")?.replaceChildren();

    try {
        if (type === "BOOKS") {
            const data = await fetchBooks({ search });
            const books = data.results.map(mapBook);

            renderCards(
                "#global-search-results",
                books,
                "No books found. Try another title."
            );

            setStatus("#global-search-status", `${books.length} books found.`);
            return;
        }

        const result = await fetchMedia({
            type,
            search,
            page: 1,
            sort: "POPULARITY_DESC"
        });

        const items = result.media.map(item => ({
            ...item,
            kind: type === "ANIME" ? "anime" : "manga"
        }));

        renderCards(
            "#global-search-results",
            items,
            "No titles found. Try another search."
        );

        setStatus("#global-search-status", `${items.length} titles found.`);
    } catch (error) {
        console.error("Search error:", error);
        setStatus(
            "#global-search-status",
            error.message || "Search failed. Check your internet connection."
        );
    }
});

/* ==========================================
   DETAILS MODAL
========================================== */

function openModal() {
    const modal = $("#detail-modal");
    if (!modal) return;

    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
}

function closeModal() {
    const modal = $("#detail-modal");
    if (!modal) return;

    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
}

document.addEventListener("keydown", event => {
    if (event.key === "Escape") closeModal();
});

function openDetails(item) {
    const body = $("#modal-body");
    if (!body) return;

    body.replaceChildren();

    const wrapper = document.createElement("div");
    wrapper.className = "modal-detail";

    const image = document.createElement("img");
    image.alt = titleFor(item);
    image.src = coverFor(item);
    image.loading = "lazy";

    if (!image.src || !coverFor(item)) image.hidden = true;

    image.addEventListener("error", () => {
        image.hidden = true;
    }, { once: true });

    const details = document.createElement("div");

    const heading = document.createElement("h2");
    heading.id = "modal-title";
    heading.textContent = titleFor(item);

    const meta = document.createElement("p");

    if (item.kind === "book") {
        meta.textContent = `${item.author || "Unknown author"} · ${(item.downloadCount || 0).toLocaleString()} downloads`;
    } else {
        meta.textContent = `${yearFor(item)} · ${scoreFor(item)} · ${item.format || item.kind}`;
    }

    const description = document.createElement("p");

    description.textContent = item.kind === "book"
        ? item.description || "Public-domain book."
        : plainText(item.description || "No description is available.");

    const genres = document.createElement("p");

    genres.textContent = item.genres?.length
        ? "Genres: " + item.genres.slice(0, 6).join(", ")
        : "";

    const actions = document.createElement("div");
    actions.className = "modal-actions";

    const save = document.createElement("button");
    save.className = "button button-primary";
    save.textContent = isSaved(item) ? "♥ Saved to library" : "+ Add to library";

    save.addEventListener("click", () => {
        toggleSaved(item);
        save.textContent = isSaved(item) ? "♥ Saved to library" : "+ Add to library";
    });

    const source = document.createElement("a");
    source.className = "button button-ghost";
    source.textContent = item.kind === "book"
        ? "Open book source ↗"
        : "View catalogue ↗";

    source.href = item.siteUrl || "https://anilist.co/";
    source.target = "_blank";
    source.rel = "noopener noreferrer";

    actions.append(save, source);

    if (item.kind === "book") {
        const read = document.createElement("button");
        read.className = "button button-ghost";
        read.textContent = "Read here";

        read.addEventListener("click", () => {
            closeModal();
            readBook(item);
        });

        actions.appendChild(read);
    }

    details.append(heading, meta, description, genres, actions);
    wrapper.append(image, details);
    body.appendChild(wrapper);

    openModal();
}

/* ==========================================
   PERSONAL LIBRARY
========================================== */

function toggleSaved(item) {
    const library = getLibrary();

    const index = library.findIndex(saved =>
        saved.kind === item.kind &&
        String(saved.id) === String(item.id)
    );

    if (index >= 0) {
        library.splice(index, 1);
        saveLibrary(library);
        showToast("Removed from your library.");
    } else {
        let storedItem;

        if (item.kind === "book") {
            storedItem = {
                ...item,
                id: String(item.id)
            };
        } else {
            storedItem = { ...item };
        }

        library.unshift(storedItem);

        if (!saveLibrary(library)) return;

        showToast("Saved to your library.");
    }

    if ($("#page-library")?.classList.contains("active-page")) {
        renderLibrary();
    }
}

function renderLibrary() {
    const library = getLibrary();

    if ($("#library-count")) {
        $("#library-count").textContent = library.length;
    }

    if ($("#library-anime-count")) {
        $("#library-anime-count").textContent =
            library.filter(item => item.kind === "anime").length;
    }

    if ($("#library-manga-count")) {
        $("#library-manga-count").textContent =
            library.filter(item => item.kind === "manga").length;
    }

    if ($("#library-books-count")) {
        $("#library-books-count").textContent =
            library.filter(item => item.kind === "book").length;
    }

    renderCards(
        "#library-results",
        library,
        "Your library is empty. Explore the Society and tap + Save."
    );

    setStatus(
        "#library-status",
        `${library.length} saved titles on this device.`
    );
}

$("#clear-library")?.addEventListener("click", () => {
    if (!getLibrary().length) {
        showToast("Your library is already empty.");
        return;
    }

    if (!confirm("Remove all saved titles from this device?")) return;

    saveLibrary([]);
    renderLibrary();
    showToast("Library cleared.");
});

$("#export-library")?.addEventListener("click", () => {
    const data = JSON.stringify({
        exportedAt: new Date().toISOString(),
        library: getLibrary(),
        readingProgress: getProgress()
    }, null, 2);

    const blob = new Blob([data], {
        type: "application/json"
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = "regression-society-library.json";
    link.click();

    setTimeout(() => URL.revokeObjectURL(url), 1000);

    showToast("Library export prepared.");
});

/* ==========================================
   BOOK READER
========================================== */

function findReadableTextURL(book) {
    const formats = book.formats || {};

    for (const [type, url] of Object.entries(formats)) {
        if (
            type.startsWith("text/plain") &&
            typeof url === "string" &&
            /^https?:\/\//i.test(url)
        ) {
            return url;
        }
    }

    return null;
}

function updateReaderFont() {
    const content = $("#reader-content");

    if (content) {
        content.style.fontSize = `${readerFontSize}px`;
    }
}

function saveReaderPosition(book, paragraphIndex) {
    if (!book) return;

    const progress = getProgress();

    progress[String(book.id)] = {
        title: titleFor(book),
        paragraphIndex,
        updatedAt: new Date().toISOString()
    };

    try {
        localStorage.setItem(STORAGE_PROGRESS, JSON.stringify(progress));
    } catch {
        showToast("Couldn't save reading progress.");
    }
}

async function readBook(book) {
    showPage("novels");

    const reader = $("#novel-reader");
    const content = $("#reader-content");

    if (!reader || !content) {
        showToast("The book reader isn't present in your HTML.");
        return;
    }

    reader.style.display = "block";
    $("#reader-title").textContent = titleFor(book);
    content.textContent = "Opening the book...";

    currentReaderBook = book;
    reader.scrollIntoView({ behavior: "smooth", block: "start" });

    const textURL = findReadableTextURL(book);

    if (!textURL) {
        content.textContent = "A readable plain-text edition isn't available here. Open the source page to explore available formats.";
        return;
    }

    try {
        const response = await fetch(textURL);

        if (!response.ok) {
            throw new Error("Text edition could not be loaded.");
        }

        const text = await response.text();

        const paragraphs = text
            .replace(/\r\n/g, "\n")
            .split(/\n\s*\n/)
            .map(paragraph => paragraph.trim())
            .filter(Boolean);

        if (!paragraphs.length) {
            throw new Error("The text edition is empty.");
        }

        const saved = getProgress()[String(book.id)];
        const start = saved?.paragraphIndex || 0;

        content.replaceChildren();

        paragraphs.slice(start).forEach((paragraph, index) => {
            const p = document.createElement("p");
            p.textContent = paragraph;

            p.addEventListener("click", () => {
                saveReaderPosition(book, start + index);
            });

            content.appendChild(p);
        });

        updateReaderFont();
        saveReaderPosition(book, start);

        showToast("Book opened.");
    } catch (error) {
        console.error("Reader error:", error);
        content.textContent = "Unable to load the book inside this browser. Open its source page instead.";
    }
}

$("#font-smaller")?.addEventListener("click", () => {
    readerFontSize = Math.max(13, readerFontSize - 1);
    updateReaderFont();
});

$("#font-larger")?.addEventListener("click", () => {
    readerFontSize = Math.min(30, readerFontSize + 1);
    updateReaderFont();
});

$("#reader-bookmark")?.addEventListener("click", () => {
    if (!currentReaderBook) {
        showToast("Open a book first.");
        return;
    }

    showToast("Reading progress is saved locally when you select a paragraph.");
});

$("#close-reader")?.addEventListener("click", () => {
    if ($("#novel-reader")) {
        $("#novel-reader").style.display = "none";
    }
});

/* ==========================================
   AUTHORIZED VIDEO PLAYER
========================================== */

$("#video-form")?.addEventListener("submit", event => {
    event.preventDefault();

    const rawURL = $("#video-url")?.value.trim() || "";

    try {
        const url = new URL(rawURL);

        if (!["http:", "https:"].includes(url.protocol)) {
            throw new Error("Invalid protocol.");
        }

        const video = $("#video-player");

        if (!video) {
            showToast("Video player not found in the HTML.");
            return;
        }

        video.pause();
        video.removeAttribute("src");
        video.src = url.href;
        video.load();

        $("#player-panel")?.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });

        showToast("Video loaded. Press play when ready.");
    } catch {
        showToast("Enter a valid HTTP or HTTPS video URL.");
    }
});

/* ==========================================
   DISCOVER PAGE
========================================== */

async function loadDiscoveries() {
    try {
        const result = await fetchMedia({
            type: "ANIME",
            page: 1,
            sort: "TRENDING_DESC"
        });

        renderCards(
            "#discover-anime-results",
            result.media.slice(0, 5).map(item => ({
                ...item,
                kind: "anime"
            })),
            "No anime results available."
        );

        setStatus("#discover-anime-status", "Trending anime from AniList.");
    } catch (error) {
        console.error(error);
        setStatus("#discover-anime-status", "Couldn't load anime. Check your connection.");
    }

    try {
        const result = await fetchMedia({
            type: "MANGA",
            page: 1,
            sort: "TRENDING_DESC"
        });

        renderCards(
            "#discover-manga-results",
            result.media.slice(0, 5).map(item => ({
                ...item,
                kind: "manga"
            })),
            "No manga results available."
        );

        setStatus("#discover-manga-status", "Trending manga from AniList.");
    } catch (error) {
        console.error(error);
        setStatus("#discover-manga-status", "Couldn't load manga.");
    }

    try {
        const data = await fetchBooks({ page: 1 });

        renderCards(
            "#discover-books-results",
            data.results.slice(0, 5).map(mapBook),
            "No public-domain books available."
        );

        setStatus("#discover-books-status", "Public-domain books from Gutendex.");
    } catch (error) {
        console.error(error);
        setStatus("#discover-books-status", "Couldn't load books.");
    }
}

/* ==========================================
   START
========================================== */

function initializeSite() {
    if ($("#novel-reader")) {
        $("#novel-reader").style.display = "none";
    }

    setButtonLoading($("#anime-load-more"), true);
    setButtonLoading($("#manga-load-more"), true);
    setButtonLoading($("#books-load-more"), true);

    renderLibrary();
    loadDiscoveries();

    console.log("Regression Society initialized successfully.");
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initializeSite);
} else {
    initializeSite();
}